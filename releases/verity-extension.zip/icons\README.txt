# Browser Extension Icons

Place PNG icons here in these sizes:
- icon16.png
- icon32.png
- icon48.png
- icon128.png

Reference these in manifest.json:
"icons": {
  "16": "icons/icon16.png",
  "32": "icons/icon32.png",
  "48": "icons/icon48.png",
  "128": "icons/icon128.png"
}
